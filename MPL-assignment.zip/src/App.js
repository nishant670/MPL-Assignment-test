import React from 'react';
import { Route, Switch } from 'react-router-dom';
// import Employee from './containers/Employee/Employee';
// import TableView from './containers/TableView/TableView';
import Dashboard from './containers/Dashboard/Dashboard';
import Auth from './containers/Auth/Auth';
// import Toolbar from './components/Navigation/Toolbar/Toolbar';
// import Layout from './hoc/Layout/Layout';

import './App.css';

function App() {
  return (
    <div className="App">
      {/* <Layout> */}
      <Switch>
        {/* <Route path="/employee" component={Employee} />
        <Route path="/table" component={TableView} /> */}
        
        <Route path="/" exact component={Auth} />
        <Route component={Dashboard} />
      </Switch>
      
      {/* </Layout> */}
    </div>
  );
}

export default App;
