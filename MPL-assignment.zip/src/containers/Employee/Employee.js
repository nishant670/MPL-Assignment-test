import React, { Component } from 'react';
import Auth from '../Auth/Auth';

export class Employee extends Component {
    render() {
        return (
            <div>
                <p>Employee page</p>
            </div>
        )
    }
}

export default Employee
