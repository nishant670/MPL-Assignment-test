import React, { Component } from 'react';
import {withRouter} from 'react-router-dom';

// import Input from '../../components/UI/Input/Input';
// import Button from '../../components/UI/Button/Button';
import './Auth.css';
  
  const validEmailRegex = RegExp(/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i);
  
  const validPasswordRegex = RegExp(/^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}$/);
  
  const validateForm = (errors) => {
    let valid = true;
    Object.values(errors).forEach(
      (val) => val.length > 0 && (valid = false)
    );
    return valid;
  }
  
  const countErrors = (errors) => {
    let count = 0;
    Object.values(errors).forEach(
      (val) => val.length > 0 && (count = count+1)
    );
    return count;
  }
  
  class Auth extends Component {
    constructor(props) {
      super(props);
      this.state = {
        formValid: false,
        errorCount: null,
        errors: {
          fullName: '',
          email: '',
          password: '',
        }
      };
    }
  
    handleChange = (event) => {
      event.preventDefault();
      const { name, value } = event.target;
      let errors = this.state.errors;
  
      switch (name) {
        case 'fullName': 
          errors.fullName = 
            value.length < 5
              ? 'Full Name must be 5 characters long!'
              : '';
          break;
        case 'email': 
          errors.email = 
            validEmailRegex.test(value)
              ? ''
              : 'Email is not valid!';
          break;
        case 'password': 
          errors.password = 
            validPasswordRegex.test(value)
              ? ''
              : 'Password must be contain letters(uppercase and lowercase), numbers and special character!';
          break;
        default:
          break;
      }
  
      this.setState({errors, [name]: value});
    }
  
    handleSubmit = (event) => {
      event.preventDefault();
      this.setState({formValid: validateForm(this.state.errors)});
      this.setState({errorCount: countErrors(this.state.errors)});
      if(this.state.formValid){
        this.props.history.push('/employee')
      }
    }
  
    render() {
      const {errors, formValid} = this.state;
      return (
        <div className='wrapper'>
          <div className='form-wrapper'>
            <form onSubmit={this.handleSubmit} noValidate>
              <div className='email'>
                <input type='email' name='email' placeholder='Username' onChange={this.handleChange} noValidate />
                {errors.email.length > 0 && 
                  <span className='error'>{errors.email}</span>}
              </div>
              <div className='password'>
                <input type='password' name='password' placeholder='Password' onChange={this.handleChange} noValidate />
                {errors.password.length > 0 && 
                  <span className='error'>{errors.password}</span>}
              </div>
              <div className='submit'>
                <button>LOGIN</button>
              </div>
            </form>
          </div>
        </div>
      );
    }
  }

export default withRouter(Auth);