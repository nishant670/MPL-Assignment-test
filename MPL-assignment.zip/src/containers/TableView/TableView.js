import React, { Component } from 'react';
import axios from 'axios';

export class TableView extends Component {

    state = {
        user : []
    }

    componentDidMount(){
        axios.get('https://5b5cb0546a725000148a67ab.mockapi.io/api/v1/users')  
        .then(response => {
                
                    this.setState({
                        // ...this.state.post,
                        
                        user : response.data
                    });
                console.log(response.data);
            })
            .catch(error => {
                return error
            })
    }

    render() {
        return (
            <div>
                <p>Table view</p>
                <table style={{width : "100%"}}>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Create Date</th>
                        <th>Name</th>
                        <th>Avatar</th>
                    </tr>
                </thead>
                <tbody>
                {
                this.state.user.map((user, i) => {
                    return <tr key={user.id}>
                        <td>
                            {user.id}
                        </td>
                    <td>
                        {user.createdAt}
                    </td>
                    <td>
                            {user.name}
                        </td>
                    <td>
                        <img src={user.avatar} width="30"></img>
                    </td>
                </tr>
        })
    }
                </tbody>
                
                {/* {showPost} */}
            </table>
            </div>
        )
    }
}

export default TableView
