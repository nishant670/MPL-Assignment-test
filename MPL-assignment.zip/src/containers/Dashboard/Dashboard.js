import React, { Component } from 'react';
import { Route } from 'react-router-dom';

import Layout from '../../hoc/Layout/Layout';
import Employee from '../Employee/Employee';
import TableView from '../TableView/TableView';

export class Dashboard extends Component {
    render() {
        return (
            <Layout>
                <Route path="/employee" component={Employee} />
        <Route path="/table" component={TableView} />
            </Layout>
        )
    }
}

export default Dashboard
