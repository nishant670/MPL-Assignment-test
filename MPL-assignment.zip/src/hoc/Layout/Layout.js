import React, { Component } from 'react';
import './Layout.css';
import Toolbar from '../../components/Navigation/Toolbar/Toolbar';

const Layout = (props) => {
    
        return (
            <div>
                <Toolbar />
                <main className="content">
                    {props.children}
                </main>
            </div>
        )
    }

export default Layout;